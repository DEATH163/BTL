<?php

require_once "app/config/database.php";

class Post
{
    private $conn;

    public function __construct()
    {
        global $conn;
        $this->conn = $conn;
    }

    public function getAllPosts()
    {
        $sql = "SELECT posts.*, categories.name as category_name
                FROM posts
                LEFT JOIN categories ON posts.category_id = categories.id
                ORDER BY posts.id DESC";
        return $this->conn->query($sql);
    }

    public function getByCategory($id)
    {
        $id  = intval($id);
        $sql = "SELECT posts.*, categories.name as category_name
                FROM posts
                LEFT JOIN categories ON posts.category_id = categories.id
                WHERE posts.category_id = $id
                ORDER BY posts.id DESC";
        return $this->conn->query($sql);
    }

    public function getPostById($id)
    {
        $id  = intval($id);
        $sql = "SELECT posts.*, categories.name as category_name
                FROM posts
                LEFT JOIN categories ON posts.category_id = categories.id
                WHERE posts.id = $id
                LIMIT 1";
        $result = $this->conn->query($sql);
        return $result ? $result->fetch_assoc() : null;
    }
}