<?php

class Comment {

    private $conn;

    public function __construct($conn){
        $this->conn = $conn;
    }

    public function getByPost($post_id){

        $sql = "SELECT * FROM comments 
                WHERE post_id = $post_id 
                ORDER BY created_at DESC";

        return $this->conn->query($sql);
    }

}