<?php

require_once "app/config/database.php";

class Category{

    private $conn;

    public function __construct(){
        global $conn;
        $this->conn = $conn;
    }

    public function getAll(){

        $sql = "SELECT * FROM categories";

        $result = $this->conn->query($sql);

        return $result;
    }

}