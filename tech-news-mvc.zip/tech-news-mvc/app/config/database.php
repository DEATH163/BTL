<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "tech_news";

$conn = new mysqli($host,$user,$password,$database);

if($conn->connect_error){

die("Kết nối database thất bại");

}