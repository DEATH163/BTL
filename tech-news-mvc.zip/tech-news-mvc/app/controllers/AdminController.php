<?php

class AdminController
{
    public function index()
    {
        // Kết nối thẳng ở đây, không dùng require
        $host     = "localhost";
        $user     = "root";
        $password = "";
        $database = "tech_news";

        $conn = new mysqli($host, $user, $password, $database);

        if ($conn->connect_error) {
            die("Kết nối database thất bại: " . $conn->connect_error);
        }

        require "app/views/layouts/header.php";
        require "app/views/admin/dashboard.php";
        require "app/views/layouts/footer.php";
    }
}