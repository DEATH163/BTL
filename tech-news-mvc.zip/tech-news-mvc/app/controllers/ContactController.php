<?php

class ContactController
{
    public function index()
    {
        require 'app/views/layouts/header.php';
        require 'app/views/contact/index.php';
        require 'app/views/layouts/footer.php';
    }
}