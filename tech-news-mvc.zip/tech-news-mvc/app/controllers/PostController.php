<?php

require_once "app/config/database.php";
require_once "app/models/Post.php";

class PostController
{
    public function index()
    {
        global $conn;

        $id   = intval($_GET['id'] ?? 1);
        $postModel = new Post();
        $post = $postModel->getPostById($id);

        // Xử lý gửi comment
        $commentAlert = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'comment') {
            $name    = trim($_POST['name'] ?? '');
            $email   = trim($_POST['email'] ?? '');
            $content = trim($_POST['content'] ?? '');
            if ($name && $content) {
                $stmt = $conn->prepare("INSERT INTO comments (post_id, name, email, content) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("isss", $id, $name, $email, $content);
                $stmt->execute();
                $stmt->close();
                header("Location: ?page=post&id=$id&commented=1");
                exit;
            } else {
                $commentAlert = '<div class="alert alert-warning alert-dismissible fade show py-2">⚠️ Vui lòng nhập tên và nội dung. <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
            }
        }

        if (isset($_GET['commented'])) {
            $commentAlert = '<div class="alert alert-success alert-dismissible fade show py-2">✅ Bình luận đã được gửi! <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        }

        // Lấy comments từ DB
        $comments = [];
        if (!empty($post)) {
            $stmt = $conn->prepare("SELECT * FROM comments WHERE post_id = ? ORDER BY created_at DESC");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $comments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        }

        // Lấy bài liên quan (cùng category_id, trừ bài hiện tại)
        $related = [];
        if (!empty($post)) {
            $catId = intval($post['category_id']);
            $stmt  = $conn->prepare("
                SELECT p.id, p.title, p.created_at, p.thumbnail
                FROM posts p
                WHERE p.category_id = ? AND p.id != ?
                ORDER BY p.id DESC
                LIMIT 4
            ");
            $stmt->bind_param("ii", $catId, $id);
            $stmt->execute();
            $related = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        }

        require "app/views/layouts/header.php";
        require "app/views/post/detail.php";
        require "app/views/layouts/footer.php";
    }
}