<?php

class CategoryController
{

    public function index()
    {

        $id = $_GET['id'] ?? 1;

        require "app/views/layouts/header.php";

        require "app/views/category/list.php";

        require "app/views/layouts/footer.php";

    }

}