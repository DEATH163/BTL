<?php

class HomeController
{

    public function index()
    {

        require "app/views/layouts/header.php";

        require "app/views/home/index.php";

        require "app/views/layouts/footer.php";

    }

}