<?php

class Router
{

    public function handleRequest()
    {

        $page = $_GET['page'] ?? 'home';

        switch ($page) {

            case 'home':
                require_once 'app/controllers/HomeController.php';
                $controller = new HomeController();
                $controller->index();
                break;

            case 'category':
                require_once 'app/controllers/CategoryController.php';
                $controller = new CategoryController();
                $controller->index();
                break;

            case 'post':
                require_once 'app/controllers/PostController.php';
                $controller = new PostController();
                $controller->index();
                break;

            // ✅ THÊM CASE SEARCH
            case 'search':
                require 'app/views/layouts/header.php';
                require 'app/views/search/index.php';
                require 'app/views/layouts/footer.php';
                break;

            case 'video':
                require 'app/views/layouts/header.php';
                require 'app/views/category/video.php';
                require 'app/views/layouts/footer.php';
                break;

            case 'contact':
                require_once 'app/controllers/ContactController.php';
                $controller = new ContactController();
                $controller->index();
                break;

            case 'admin':
                require_once 'app/controllers/AdminController.php';
                $controller = new AdminController();
                $controller->index();
                break;

            default:
                require_once 'app/controllers/HomeController.php';
                $controller = new HomeController();
                $controller->index();
                break;
        }
    }
}