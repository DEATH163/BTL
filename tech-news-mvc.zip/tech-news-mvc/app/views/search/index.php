<?php


$keyword = trim($_GET['keyword'] ?? '');

// Toàn bộ bài viết để tìm kiếm
$allPosts = [
    ['id'=>1,  'title'=>'AI đang thay đổi thế giới lập trình',    'desc'=>'Copilot và ChatGPT giúp lập trình viên tăng năng suất lên 40%.',            'category'=>'AI',        'date'=>'28/02/2026'],
    ['id'=>2,  'title'=>'Apple ra mắt chip M4 mới',                'desc'=>'M4 trên tiến trình 3nm nhanh hơn 30% và tiết kiệm pin hơn 40%.',            'category'=>'Mobile',    'date'=>'27/02/2026'],
    ['id'=>3,  'title'=>'Xu hướng Cyber Security 2026',            'desc'=>'Zero Trust và AI-powered Security là xu hướng nổi bật nhất.',               'category'=>'Security',  'date'=>'26/02/2026'],
    ['id'=>4,  'title'=>'Top framework lập trình hot nhất 2026',   'desc'=>'Next.js, Laravel, FastAPI và Rust đang dẫn đầu xu hướng.',                  'category'=>'Lập trình', 'date'=>'25/02/2026'],
    ['id'=>5,  'title'=>'ChatGPT và tương lai AI',                  'desc'=>'GPT-5 kỳ vọng suy luận ngang tầm con người.',                               'category'=>'AI',        'date'=>'24/02/2026'],
    ['id'=>6,  'title'=>'Google ra mắt Gemini 2.0',                 'desc'=>'Gemini 2.0 Ultra tích hợp toàn bộ hệ sinh thái Google.',                    'category'=>'AI',        'date'=>'23/02/2026'],
    ['id'=>7,  'title'=>'Samsung Galaxy S26 Series ra mắt',         'desc'=>'Camera 200MP, Snapdragon 8 Elite Gen 2 và pin 5000mAh.',                    'category'=>'Mobile',    'date'=>'22/02/2026'],
    ['id'=>8,  'title'=>'Windows 12 lộ diện với AI',               'desc'=>'Copilot tích hợp sâu vào mọi tác vụ hệ điều hành.',                        'category'=>'Công nghệ', 'date'=>'21/02/2026'],
    ['id'=>9,  'title'=>'Meta phát triển kính VR thế hệ mới',      'desc'=>'Meta Quest 4 nhẹ hơn 40%, độ phân giải 4K per eye.',                       'category'=>'Công nghệ', 'date'=>'20/02/2026'],
    ['id'=>15, 'title'=>'Học PHP trong 30 ngày',                    'desc'=>'Lộ trình từ cú pháp cơ bản đến mini project hoàn chỉnh.',                   'category'=>'Lập trình', 'date'=>'18/02/2026'],
    ['id'=>16, 'title'=>'Laravel cho người mới bắt đầu',            'desc'=>'Eloquent ORM, Blade engine và Artisan CLI.',                                 'category'=>'Lập trình', 'date'=>'17/02/2026'],
    ['id'=>17, 'title'=>'JavaScript cơ bản đến nâng cao',           'desc'=>'ES2025, React, Node.js và full-stack development.',                          'category'=>'Lập trình', 'date'=>'16/02/2026'],
    ['id'=>18, 'title'=>'Python AI Tutorial từ Zero đến Hero',      'desc'=>'Từ NumPy, Pandas đến TensorFlow và Transformer.',                           'category'=>'AI',        'date'=>'15/02/2026'],
];

// Tìm kiếm
$results = [];
if ($keyword !== '') {
    $kw = mb_strtolower($keyword);
    foreach ($allPosts as $post) {
        if (
            mb_strpos(mb_strtolower($post['title']), $kw) !== false ||
            mb_strpos(mb_strtolower($post['desc']), $kw) !== false ||
            mb_strpos(mb_strtolower($post['category']), $kw) !== false
        ) {
            $results[] = $post;
        }
    }
}
?>

<div class="container mt-4">

    <h2 class="mb-2">
        🔍 Kết quả tìm kiếm
        <?php if ($keyword): ?>
            cho "<strong><?= htmlspecialchars($keyword) ?></strong>"
        <?php endif; ?>
    </h2>

    <!-- Ô tìm kiếm lại -->
    <form method="GET" class="mb-4">
        <input type="hidden" name="page" value="search">
        <div class="input-group">
            <input
                type="search"
                name="keyword"
                class="form-control form-control-lg"
                placeholder="Tìm kiếm bài viết..."
                value="<?= htmlspecialchars($keyword) ?>"
            >
            <button class="btn btn-primary btn-lg">Tìm kiếm</button>
        </div>
    </form>

    <?php if ($keyword === ''): ?>
        <div class="alert alert-info">Nhập từ khóa để tìm kiếm bài viết.</div>

    <?php elseif (empty($results)): ?>
        <div class="alert alert-warning">
            Không tìm thấy bài viết nào cho "<strong><?= htmlspecialchars($keyword) ?></strong>".
            <a href="?page=home">Về trang chủ</a>
        </div>

    <?php else: ?>
        <p class="text-muted mb-4">Tìm thấy <strong><?= count($results) ?></strong> kết quả</p>

        <div class="row">
            <?php foreach ($results as $post): ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm h-100 border-0">
                    <img
                        src="public/images/post.jpg"
                        class="card-img-top"
                        onerror="this.src='https://picsum.photos/400/200?random=<?= $post['id'] ?>'"
                    >
                    <div class="card-body d-flex flex-column">
                        <span class="badge bg-primary mb-2 align-self-start"><?= $post['category'] ?></span>
                        <h5 class="card-title fw-bold"><?= htmlspecialchars($post['title']) ?></h5>
                        <p class="card-text text-muted small flex-grow-1"><?= htmlspecialchars($post['desc']) ?></p>
                        <div class="d-flex justify-content-between align-items-center mt-2">
                            <small class="text-muted">📅 <?= $post['date'] ?></small>
                            <a href="?page=post&id=<?= $post['id'] ?>" class="btn btn-primary btn-sm">
                                Xem chi tiết →
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>