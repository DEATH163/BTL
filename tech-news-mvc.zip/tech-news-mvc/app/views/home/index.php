<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<!-- =============================== -->
<!-- HERO SECTION -->
<!-- =============================== -->

<div class="container mt-4">

<div class="row">

<div class="col-lg-8">

<div class="card shadow-lg border-0">

<img 
src="https://picsum.photos/1200/500?tech=1"
class="card-img-top"
style="height:350px;object-fit:cover;"
loading="lazy"
>

<div class="card-body">

<h2 class="card-title">
Tin Công Nghệ Nổi Bật Trong Ngày
</h2>

<p class="text-muted">
Cập nhật những tin tức công nghệ mới nhất về AI,
điện thoại, lập trình và xu hướng công nghệ toàn cầu.
</p>

<a href="?page=post&id=1" class="btn btn-primary">
Đọc ngay
</a>

</div>
</div>
</div>

<!-- SIDEBAR -->

<div class="col-lg-4">

<div class="card shadow-sm mb-3">

<div class="card-header bg-dark text-white">
Nổi bật
</div>

<ul class="list-group list-group-flush">

<li class="list-group-item"><a href="?page=post&id=1" class="text-decoration-none text-dark">AI đang thay đổi thế giới lập trình</a></li>
<li class="list-group-item"><a href="?page=post&id=2" class="text-decoration-none text-dark">Apple ra mắt chip M4 mới</a></li>
<li class="list-group-item"><a href="?page=post&id=3" class="text-decoration-none text-dark">Xu hướng Cyber Security 2026</a></li>
<li class="list-group-item"><a href="?page=post&id=4" class="text-decoration-none text-dark">Top framework lập trình hot nhất</a></li>
<li class="list-group-item"><a href="?page=post&id=5" class="text-decoration-none text-dark">ChatGPT và tương lai AI</a></li>

</ul>
</div>

<div class="card shadow-sm mb-3">

<div class="card-header bg-secondary text-white">
Gần đây
</div>

<ul class="list-group list-group-flush">

<li class="list-group-item"><a href="?page=post&id=6" class="text-decoration-none text-dark">Google ra mắt AI Gemini</a></li>
<li class="list-group-item"><a href="?page=post&id=7" class="text-decoration-none text-dark">Samsung Galaxy mới</a></li>
<li class="list-group-item"><a href="?page=post&id=8" class="text-decoration-none text-dark">Windows 12 lộ diện</a></li>
<li class="list-group-item"><a href="?page=post&id=9" class="text-decoration-none text-dark">Meta phát triển VR</a></li>

</ul>
</div>

<div class="card shadow-sm">

<div class="card-header bg-warning text-dark">
Top View
</div>

<ul class="list-group list-group-flush">

<li class="list-group-item"><a href="?page=post&id=15" class="text-decoration-none text-dark">Học PHP trong 30 ngày</a></li>
<li class="list-group-item"><a href="?page=post&id=16" class="text-decoration-none text-dark">Laravel cho người mới</a></li>
<li class="list-group-item"><a href="?page=post&id=17" class="text-decoration-none text-dark">JavaScript cơ bản</a></li>
<li class="list-group-item"><a href="?page=post&id=18" class="text-decoration-none text-dark">Python AI tutorial</a></li>

</ul>

</div>

</div>
</div>
</div>


<!-- =============================== -->
<!-- DANH SÁCH BÀI VIẾT -->
<!-- =============================== -->

<div class="container mt-5">

<h2 class="mb-4">
Tin Công Nghệ Mới Nhất
</h2>

<div class="row">

<?php for($i = 1; $i <= 9; $i++): ?>

<div class="col-md-4">

<div class="card mb-4 shadow-sm">

<img 
src="https://picsum.photos/600/400?random=<?= $i ?>"
class="card-img-top"
style="height:200px;object-fit:cover;"
loading="lazy"
>

<div class="card-body">

<h5 class="card-title">
Bài viết công nghệ số <?= $i ?>
</h5>

<p class="card-text">
Công nghệ đang phát triển cực kỳ nhanh chóng.
Google, Apple và Microsoft liên tục ra mắt
các sản phẩm mới.
</p>

<a href="?page=post&id=<?= $i ?>" class="btn btn-outline-primary btn-sm">
Xem chi tiết
</a>

</div>

</div>

</div>

<?php endfor; ?>

</div>

<!-- PAGINATION -->

<nav>
<ul class="pagination justify-content-center">
<li class="page-item active"><a class="page-link" href="#">1</a></li>
<li class="page-item"><a class="page-link" href="#">2</a></li>
<li class="page-item"><a class="page-link" href="#">3</a></li>
</ul>
</nav>

</div>


<!-- =============================== -->
<!-- VIDEO TECH -->
<!-- =============================== -->

<div class="container mt-5">

<h2 class="mb-4">
Video Công Nghệ
</h2>

<div class="row">

<div class="col-md-6">

<div class="ratio ratio-16x9">

<iframe 
src="https://www.youtube.com/embed/dQw4w9WgXcQ"
allowfullscreen>
</iframe>

</div>

</div>

<div class="col-md-6">

<h4>
AI đang thay đổi ngành lập trình
</h4>

<p>
AI giúp lập trình viên tăng năng suất.
Các công cụ như ChatGPT và Copilot
giúp viết code nhanh hơn.
</p>

<a href="?page=post&id=1" class="btn btn-outline-primary">
Đọc thêm →
</a>

</div>

</div>

</div>


<!-- =============================== -->
<!-- BÀI VIẾT HOT -->
<!-- =============================== -->

<div class="container mt-5">

<h2 class="mb-4">
Bài viết được đọc nhiều
</h2>

<div class="row">

<?php for($i = 1; $i <= 6; $i++): ?>

<div class="col-md-2">

<div class="card shadow-sm">

<img 
src="https://picsum.photos/300/200?random=<?= $i+20 ?>"
class="card-img-top"
style="height:120px;object-fit:cover;"
loading="lazy"
>

<div class="card-body">

<p class="small">
<a href="?page=post&id=<?= $i ?>" class="text-decoration-none text-dark">
Tin hot <?= $i ?>
</a>
</p>

</div>

</div>

</div>

<?php endfor; ?>

</div>

</div>


<!-- =============================== -->
<!-- NEWSLETTER -->
<!-- =============================== -->

<div class="container mt-5">

<div class="card bg-dark text-white p-4">

<h3>Đăng ký nhận tin công nghệ</h3>

<p>Nhận tin tức mới nhất về AI và lập trình.</p>

<form class="row">

<div class="col-md-8">
<input type="email" class="form-control" placeholder="Nhập email của bạn">
</div>

<div class="col-md-4">
<button type="button" class="btn btn-primary w-100">
Đăng ký
</button>
</div>

</form>

</div>

</div>


<!-- =============================== -->
<!-- CATEGORY SECTION -->
<!-- =============================== -->

<div class="container mt-5 mb-5">

<h2 class="mb-4">
Danh mục công nghệ
</h2>

<div class="row">

<div class="col-md-3">
<a href="?page=category&slug=ai" class="text-decoration-none">
<div class="card text-center shadow-sm h-100 border-primary">
<div class="card-body">
<h2>🤖</h2>
<h5>AI</h5>
<p class="text-muted small">Artificial Intelligence</p>
</div>
</div>
</a>
</div>

<div class="col-md-3">
<a href="?page=category&slug=mobile" class="text-decoration-none">
<div class="card text-center shadow-sm h-100 border-success">
<div class="card-body">
<h2>📱</h2>
<h5>Mobile</h5>
<p class="text-muted small">Điện thoại</p>
</div>
</div>
</a>
</div>

<div class="col-md-3">
<a href="?page=category&slug=security" class="text-decoration-none">
<div class="card text-center shadow-sm h-100 border-danger">
<div class="card-body">
<h2>🔒</h2>
<h5>Security</h5>
<p class="text-muted small">An ninh mạng</p>
</div>
</div>
</a>
</div>

<div class="col-md-3">
<a href="?page=category&slug=programming" class="text-decoration-none">
<div class="card text-center shadow-sm h-100 border-warning">
<div class="card-body">
<h2>💻</h2>
<h5>Programming</h5>
<p class="text-muted small">Lập trình</p>
</div>
</div>
</a>
</div>

</div>

</div>