<?php
// $post, $comments, $related, $commentAlert đến từ PostController
// Nếu bài viết không tồn tại
if (empty($post)): ?>
    <div class="container mt-5 text-center">
        <h2 class="text-danger">❌ Không tìm thấy bài viết</h2>
        <a href="?page=home" class="btn btn-primary mt-3">← Về trang chủ</a>
    </div>
<?php return; endif;

$thumbUrl = (!empty($post['thumbnail']) && str_starts_with($post['thumbnail'], 'http'))
    ? $post['thumbnail']
    : "https://picsum.photos/seed/post{$post['id']}/800/450";

$avatarColors = ['bg-primary','bg-success','bg-danger','bg-warning','bg-info','bg-secondary'];
?>

<div class="container mt-4">

    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="?page=home">Trang chủ</a></li>
            <li class="breadcrumb-item">
                <a href="?page=category&id=<?= $post['category_id'] ?>">
                    <?= htmlspecialchars($post['category_name'] ?? 'Danh mục') ?>
                </a>
            </li>
            <li class="breadcrumb-item active text-truncate" style="max-width:300px">
                <?= htmlspecialchars($post['title']) ?>
            </li>
        </ol>
    </nav>

    <div class="row">

        <!-- NỘI DUNG BÀI VIẾT -->
        <div class="col-lg-8">
            <div class="card shadow border-0 mb-4">
                <div class="card-body p-4">

                    <span class="badge bg-primary mb-2">
                        <?= htmlspecialchars($post['category_name'] ?? '') ?>
                    </span>
                    <h1 class="fw-bold mb-2"><?= htmlspecialchars($post['title']) ?></h1>
                    <p class="text-muted mb-3">
                        <i class="bi bi-calendar3"></i>
                        <?= date('d/m/Y H:i', strtotime($post['created_at'])) ?>
                    </p>

                    <img src="<?= $thumbUrl ?>"
                         class="img-fluid rounded mb-4 w-100"
                         style="max-height:420px;object-fit:cover"
                         alt="<?= htmlspecialchars($post['title']) ?>"
                         onerror="this.src='https://picsum.photos/seed/post<?= $post['id'] ?>/800/450'">

                    <div class="fs-5 lh-lg">
                        <?= nl2br(htmlspecialchars($post['content'])) ?>
                    </div>

                    <!-- Chia sẻ -->
                    <hr>
                    <div class="d-flex gap-2 align-items-center flex-wrap">
                        <strong>Chia sẻ:</strong>
                        <a href="https://facebook.com/sharer/sharer.php?u=<?= urlencode($_SERVER['REQUEST_URI']) ?>"
                           target="_blank" class="btn btn-sm btn-primary">📘 Facebook</a>
                        <a href="https://twitter.com/intent/tweet?text=<?= urlencode($post['title']) ?>"
                           target="_blank" class="btn btn-sm btn-info text-white">🐦 Twitter</a>
                    </div>

                </div>
            </div>

            <!-- ==================== BÌNH LUẬN ==================== -->
            <div class="card shadow border-0 mb-4">
                <div class="card-body p-4">

                    <h4 class="mb-3">
                        💬 Bình luận
                        <span class="badge bg-secondary ms-1"><?= count($comments) ?></span>
                    </h4>

                    <?= $commentAlert ?? '' ?>

                    <!-- Danh sách comment từ DB -->
                    <?php if (empty($comments)): ?>
                        <p class="text-muted fst-italic">Chưa có bình luận nào. Hãy là người đầu tiên!</p>
                    <?php else: ?>
                        <?php foreach ($comments as $i => $c):
                            $colorClass = $avatarColors[$i % count($avatarColors)];
                            $initial = mb_strtoupper(mb_substr($c['name'], 0, 1));
                        ?>
                        <div class="d-flex gap-3 mb-3">
                            <div class="rounded-circle text-white d-flex align-items-center justify-content-center fw-bold flex-shrink-0 <?= $colorClass ?>"
                                 style="width:42px;height:42px;font-size:1.1rem">
                                <?= $initial ?>
                            </div>
                            <div class="bg-light rounded p-3 w-100">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <strong><?= htmlspecialchars($c['name']) ?></strong>
                                    <small class="text-muted">
                                        <?= date('d/m/Y H:i', strtotime($c['created_at'])) ?>
                                    </small>
                                </div>
                                <p class="mb-0"><?= nl2br(htmlspecialchars($c['content'])) ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <hr>

                    <!-- Form gửi comment -->
                    <h5 class="mb-3">✍️ Để lại bình luận</h5>
                    <form method="POST" action="?page=post&id=<?= $post['id'] ?>">
                        <input type="hidden" name="action" value="comment">
                        <div class="row g-2 mb-2">
                            <div class="col-md-6">
                                <input type="text" name="name" class="form-control"
                                       placeholder="Tên của bạn *" required
                                       value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="email" name="email" class="form-control"
                                       placeholder="Email (không bắt buộc)"
                                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                            </div>
                        </div>
                        <textarea name="content" class="form-control mb-2" rows="4"
                                  placeholder="Nội dung bình luận *" required></textarea>
                        <button type="submit" class="btn btn-primary">
                            📨 Gửi bình luận
                        </button>
                    </form>

                </div>
            </div>
        </div>

        <!-- SIDEBAR -->
        <div class="col-lg-4">

            <!-- Bài liên quan -->
            <?php if (!empty($related)): ?>
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white fw-bold">
                    📌 Bài viết cùng chủ đề
                </div>
                <ul class="list-group list-group-flush">
                    <?php foreach ($related as $r):
                        $rThumb = (!empty($r['thumbnail']) && str_starts_with($r['thumbnail'], 'http'))
                            ? $r['thumbnail']
                            : "https://picsum.photos/seed/post{$r['id']}/120/80";
                    ?>
                    <li class="list-group-item px-3 py-2">
                        <div class="d-flex gap-2 align-items-center">
                            <img src="<?= $rThumb ?>" style="width:56px;height:42px;object-fit:cover;border-radius:4px"
                                 alt="" onerror="this.src='https://picsum.photos/seed/post<?= $r['id'] ?>/120/80'">
                            <div>
                                <a href="?page=post&id=<?= $r['id'] ?>"
                                   class="text-decoration-none text-dark fw-semibold small">
                                    <?= htmlspecialchars($r['title']) ?>
                                </a>
                                <small class="d-block text-muted">
                                    <?= date('d/m/Y', strtotime($r['created_at'])) ?>
                                </small>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <!-- Newsletter -->
            <div class="card bg-dark text-white shadow-sm">
                <div class="card-body">
                    <h6 class="fw-bold">📧 Đăng ký nhận tin</h6>
                    <p class="small mb-2">Nhận tin công nghệ mới nhất mỗi ngày</p>
                    <input type="email" class="form-control form-control-sm mb-2" placeholder="Email của bạn">
                    <button class="btn btn-warning btn-sm w-100">Đăng ký</button>
                </div>
            </div>

        </div>

    </div>
</div>