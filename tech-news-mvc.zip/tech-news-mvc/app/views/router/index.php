<?php
$page = $_GET['page'] ?? 'home';

switch($page) {
    case 'home':
        require_once __DIR__ . '/views/home/index.php';
        break;
    case 'category':
        require_once __DIR__ . '/views/category/list.php';
        break;
    case 'laptrinh':
        require_once __DIR__ . '/views/category/laptrinh.php';
        break;
    case 'sukien':
        require_once __DIR__ . '/views/category/sukien.php';
        break;
    case 'thuthuat':
        require_once __DIR__ . '/views/category/thuthuat.php';
        break;
    case 'post':
        require_once __DIR__ . '/views/post/index.php';
        break;
    case 'search':
        require_once __DIR__ . '/views/search/index.php';
        break;
    case 'video':
        require_once __DIR__ . '/views/video/index.php';
        break;
    case 'contact':
        require_once __DIR__ . '/views/contact/index.php';
        break;
    case 'admin':
        require_once __DIR__ . '/views/admin/index.php';
        break;
    default:
        require_once __DIR__ . '/views/home/index.php';
        break;
}