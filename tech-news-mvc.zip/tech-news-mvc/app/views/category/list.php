<?php
require_once __DIR__ . '/../layouts/header.php';

// Hỗ trợ cả id và slug
$id   = intval($_GET['id'] ?? 0);
$slug = $_GET['slug'] ?? '';

// Map slug => id
$slugMap = [
    'ai'          => 2,
    'mobile'      => 5,
    'security'    => 3,
    'programming' => 4,
    'congnghé'    => 1,
    'laptrinh'    => 4,
    'sukien'      => 7,
    'thuthuat'    => 8,
];

if ($slug && isset($slugMap[$slug])) {
    $id = $slugMap[$slug];
}

$categories = [
    1 => ['name' => 'Công nghệ',  'icon' => '🖥️',  'color' => 'primary'],
    2 => ['name' => 'AI',         'icon' => '🤖',  'color' => 'success'],
    3 => ['name' => 'Security',   'icon' => '🔒',  'color' => 'danger'],
    4 => ['name' => 'Lập trình',  'icon' => '💻',  'color' => 'warning'],
    5 => ['name' => 'Mobile',     'icon' => '📱',  'color' => 'info'],
    6 => ['name' => 'Video',      'icon' => '🎬',  'color' => 'secondary'],
    7 => ['name' => 'Sự kiện',    'icon' => '📅',  'color' => 'primary'],
    8 => ['name' => 'Thủ thuật',  'icon' => '🔧',  'color' => 'dark'],
];

$cat = $categories[$id] ?? ['name' => 'Tin tức', 'icon' => '📰', 'color' => 'primary'];

// Bài viết mẫu theo danh mục
$allPosts = [
    1 => [
        ['id'=>8,  'title'=>'Windows 12 lộ diện với AI',             'desc'=>'Microsoft hé lộ Windows 12 với giao diện AI hoàn toàn mới và Copilot tích hợp sâu.',        'date'=>'21/02/2026'],
        ['id'=>9,  'title'=>'Meta phát triển kính VR thế hệ mới',     'desc'=>'Meta Quest 4 nhẹ hơn 40%, độ phân giải 4K per eye và avatar cảm xúc thời gian thực.',       'date'=>'20/02/2026'],
        ['id'=>10, 'title'=>'Intel Lunar Lake hiệu năng vượt trội',    'desc'=>'Chip Intel Lunar Lake mang lại hiệu năng AI xử lý on-device tốt nhất trong lớp laptop mỏng.', 'date'=>'19/02/2026'],
        ['id'=>11, 'title'=>'AMD Ryzen 9000 series ra mắt',            'desc'=>'AMD Ryzen 9000 với kiến trúc Zen 5 cải thiện IPC lên tới 16% so với thế hệ trước.',         'date'=>'18/02/2026'],
        ['id'=>12, 'title'=>'NVIDIA GeForce RTX 5090 phá kỷ lục',      'desc'=>'Card đồ họa mạnh nhất lịch sử với 32GB GDDR7 và hiệu năng ray tracing gấp đôi 4090.',      'date'=>'17/02/2026'],
        ['id'=>13, 'title'=>'Quantum Computing bước ngoặt mới',        'desc'=>'IBM đạt mốc 1000 qubit, mở ra kỷ nguyên máy tính lượng tử thực tế.',                        'date'=>'16/02/2026'],
    ],
    2 => [
        ['id'=>1,  'title'=>'AI đang thay đổi thế giới lập trình',    'desc'=>'Copilot và ChatGPT giúp lập trình viên tăng năng suất lên 40% theo khảo sát mới nhất.',     'date'=>'28/02/2026'],
        ['id'=>5,  'title'=>'ChatGPT và tương lai AI',                  'desc'=>'GPT-5 kỳ vọng suy luận ngang tầm con người, mở ra kỷ nguyên AI agent.',                      'date'=>'24/02/2026'],
        ['id'=>6,  'title'=>'Google ra mắt Gemini 2.0',                 'desc'=>'Gemini 2.0 Ultra tích hợp vào toàn bộ hệ sinh thái Google với khả năng đa phương thức.',     'date'=>'23/02/2026'],
        ['id'=>18, 'title'=>'Python AI Tutorial từ Zero đến Hero',      'desc'=>'Lộ trình học AI với Python từ NumPy, Pandas đến TensorFlow và Transformer.',                'date'=>'15/02/2026'],
        ['id'=>20, 'title'=>'Stable Diffusion 4.0 ra mắt',             'desc'=>'Tạo ảnh AI chất lượng 8K với stable diffusion thế hệ mới, hỗ trợ video generation.',       'date'=>'14/02/2026'],
        ['id'=>21, 'title'=>'Claude 4 của Anthropic',                   'desc'=>'Anthropic ra mắt Claude 4 với khả năng lập luận phức tạp và context window 2 triệu token.', 'date'=>'13/02/2026'],
    ],
    3 => [
        ['id'=>3,  'title'=>'Xu hướng Cyber Security 2026',            'desc'=>'Zero Trust và AI-powered Security là hai xu hướng bảo mật nổi bật nhất năm nay.',           'date'=>'26/02/2026'],
        ['id'=>30, 'title'=>'Ransomware tấn công 500 doanh nghiệp',    'desc'=>'Làn sóng tấn công ransomware mới nhắm vào cơ sở hạ tầng quan trọng toàn cầu.',             'date'=>'25/02/2026'],
        ['id'=>31, 'title'=>'VPN nào an toàn nhất 2026',               'desc'=>'Đánh giá top 10 VPN tốt nhất cho cả bảo mật lẫn tốc độ kết nối.',                         'date'=>'24/02/2026'],
        ['id'=>32, 'title'=>'Passkey thay thế mật khẩu hoàn toàn',     'desc'=>'Apple, Google và Microsoft đồng loạt hỗ trợ Passkey, xóa bỏ kỷ nguyên password.',          'date'=>'23/02/2026'],
        ['id'=>33, 'title'=>'Lỗ hổng bảo mật Android nghiêm trọng',    'desc'=>'Google phát hành bản vá khẩn cấp cho lỗ hổng zero-day ảnh hưởng 1 tỷ thiết bị.',          'date'=>'22/02/2026'],
        ['id'=>34, 'title'=>'Bug bounty 1 triệu USD từ Microsoft',      'desc'=>'Microsoft tăng mức thưởng phát hiện lỗ hổng lên 1 triệu USD cho các lỗi nghiêm trọng.',    'date'=>'21/02/2026'],
    ],
    4 => [
        ['id'=>4,  'title'=>'Top framework lập trình hot nhất 2026',   'desc'=>'Next.js, Laravel, FastAPI và Rust đang dẫn đầu xu hướng công nghệ năm nay.',               'date'=>'25/02/2026'],
        ['id'=>15, 'title'=>'Học PHP trong 30 ngày',                    'desc'=>'Lộ trình từ cú pháp cơ bản đến OOP, database và mini project hoàn chỉnh.',                 'date'=>'18/02/2026'],
        ['id'=>16, 'title'=>'Laravel cho người mới bắt đầu',            'desc'=>'Eloquent ORM, Blade engine và Artisan CLI giúp phát triển PHP nhanh hơn.',                  'date'=>'17/02/2026'],
        ['id'=>17, 'title'=>'JavaScript cơ bản đến nâng cao',           'desc'=>'ES2025, React, Node.js và lộ trình trở thành full-stack developer.',                        'date'=>'16/02/2026'],
        ['id'=>40, 'title'=>'Rust - Ngôn ngữ an toàn nhất thế giới',   'desc'=>'Tại sao Linux kernel và Windows đang chuyển sang sử dụng Rust thay thế C++.',             'date'=>'15/02/2026'],
        ['id'=>41, 'title'=>'DevOps với Docker và Kubernetes',           'desc'=>'Hướng dẫn triển khai microservices với container orchestration thực tế.',                  'date'=>'14/02/2026'],
    ],
    5 => [
        ['id'=>2,  'title'=>'Apple ra mắt chip M4 mới',                'desc'=>'M4 trên tiến trình 3nm nhanh hơn 30% và tiết kiệm pin hơn 40% so với M3.',                'date'=>'27/02/2026'],
        ['id'=>7,  'title'=>'Samsung Galaxy S26 Series ra mắt',         'desc'=>'Camera 200MP, Snapdragon 8 Elite Gen 2 và pin 5000mAh sạc nhanh 65W.',                     'date'=>'22/02/2026'],
        ['id'=>50, 'title'=>'Xiaomi 15 Ultra về Việt Nam',              'desc'=>'Leica camera 4 ống kính, Snapdragon 8 Elite và sạc không dây 90W.',                        'date'=>'20/02/2026'],
        ['id'=>51, 'title'=>'Google Pixel 9 Pro review chi tiết',       'desc'=>'Camera AI tốt nhất Android, Magic Eraser 2.0 và 7 năm cập nhật phần mềm.',               'date'=>'19/02/2026'],
        ['id'=>52, 'title'=>'iPhone 17 Pro Max lộ thiết kế',            'desc'=>'Màn hình foldable, camera periscope 5x và chip A19 Bionic được tiết lộ qua rò rỉ.',       'date'=>'18/02/2026'],
        ['id'=>53, 'title'=>'OPPO Find X8 Ultra - siêu phẩm camera',   'desc'=>'Hasselblad camera với sensor 1 inch, zoom quang học 10x và video 8K.',                    'date'=>'17/02/2026'],
    ],
    7 => [
        ['id'=>60, 'title'=>'Google I/O 2026 - Tất cả công bố nổi bật',      'desc'=>'Google công bố Android 16, Gemini Ultra 2.0 và kính AR mới tại sự kiện lớn nhất năm.',    'date'=>'20/05/2026'],
        ['id'=>61, 'title'=>'Apple WWDC 2026 - iOS 20 ra mắt',                'desc'=>'Apple hé lộ iOS 20 với AI tích hợp sâu và thiết kế hoàn toàn mới.',                       'date'=>'10/06/2026'],
        ['id'=>62, 'title'=>'Microsoft Build 2026 - Windows AI Platform',     'desc'=>'Microsoft ra mắt nền tảng AI cho Windows, Copilot Studio và Azure AI thế hệ mới.',         'date'=>'22/05/2026'],
        ['id'=>63, 'title'=>'CES 2026 - Những sản phẩm công nghệ đỉnh nhất', 'desc'=>'TV 16K, robot gia đình và xe tự lái thế hệ mới gây bão tại Las Vegas.',                   'date'=>'07/01/2026'],
        ['id'=>64, 'title'=>'MWC 2026 - Xu hướng di động toàn cầu',           'desc'=>'Samsung, Xiaomi và các hãng lớn trình diễn flagship mới tại Mobile World Congress.',      'date'=>'25/02/2026'],
        ['id'=>65, 'title'=>'VietnamTech Summit 2026',                         'desc'=>'Hội nghị công nghệ lớn nhất Việt Nam với 500+ diễn giả và 10.000 tham dự viên.',          'date'=>'15/03/2026'],
    ],
    8 => [
        ['id'=>70, 'title'=>'10 cách tăng tốc Windows 11 hiệu quả',          'desc'=>'Tắt startup apps, dọn dẹp registry và tối ưu RAM giúp máy tính nhanh hơn hẳn.',           'date'=>'27/02/2026'],
        ['id'=>71, 'title'=>'Cách bảo mật tài khoản Google tuyệt đối',       'desc'=>'Bật 2FA, kiểm tra phiên đăng nhập và thiết lập khóa bảo mật vật lý.',                    'date'=>'26/02/2026'],
        ['id'=>72, 'title'=>'Tăng tốc Chrome - 8 mẹo cực hay',               'desc'=>'Xóa cache, tắt extension thừa và bật GPU acceleration để trình duyệt mượt hơn.',         'date'=>'25/02/2026'],
        ['id'=>73, 'title'=>'Khôi phục file đã xóa trên Windows và Mac',     'desc'=>'Dùng Recuva, TestDisk và Time Machine để lấy lại dữ liệu quan trọng đã mất.',            'date'=>'24/02/2026'],
        ['id'=>74, 'title'=>'Dùng AI để tăng năng suất làm việc gấp đôi',    'desc'=>'Kết hợp ChatGPT, Notion AI và Copilot vào quy trình làm việc hàng ngày hiệu quả.',       'date'=>'23/02/2026'],
        ['id'=>75, 'title'=>'Thiết lập VPN miễn phí an toàn nhất 2026',      'desc'=>'Hướng dẫn cài đặt Proton VPN, Windscribe và cấu hình WireGuard tự host.',                'date'=>'22/02/2026'],
    ],
];

$posts = $allPosts[$id] ?? $allPosts[1];
?>

<div class="container mt-4">

    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="?page=home">Trang chủ</a></li>
            <li class="breadcrumb-item active"><?= $cat['icon'] ?> <?= $cat['name'] ?></li>
        </ol>
    </nav>

    <!-- Tiêu đề danh mục -->
    <div class="alert alert-<?= $cat['color'] ?> d-flex align-items-center gap-3 mb-4">
        <span style="font-size:2rem"><?= $cat['icon'] ?></span>
        <div>
            <h3 class="mb-0 fw-bold">Danh mục: <?= $cat['name'] ?></h3>
            <small>Tổng <?= count($posts) ?> bài viết</small>
        </div>
    </div>

    <!-- Tất cả danh mục -->
    <div class="d-flex gap-2 flex-wrap mb-4">
        <?php foreach ($categories as $cid => $c): ?>
        <a href="?page=category&id=<?= $cid ?>"
           class="btn btn-sm btn-<?= ($cid == $id) ? $c['color'] : 'outline-'.$c['color'] ?>">
            <?= $c['icon'] ?> <?= $c['name'] ?>
        </a>
        <?php endforeach; ?>
    </div>

    <div class="row">

        <!-- Danh sách bài viết -->
        <div class="col-lg-8">
            <div class="row">
                <?php foreach ($posts as $post): ?>
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm h-100 border-0">
                        <img
                            src="public/images/post.jpg"
                            class="card-img-top"
                            alt="<?= htmlspecialchars($post['title']) ?>"
                            onerror="this.src='https://picsum.photos/400/250?random=<?= $post['id'] ?>'"
                        >
                        <div class="card-body d-flex flex-column">
                            <span class="badge bg-<?= $cat['color'] ?> mb-2 align-self-start"><?= $cat['name'] ?></span>
                            <h5 class="card-title fw-bold"><?= htmlspecialchars($post['title']) ?></h5>
                            <p class="card-text text-muted small flex-grow-1"><?= htmlspecialchars($post['desc']) ?></p>
                            <div class="d-flex justify-content-between align-items-center mt-2">
                                <small class="text-muted">📅 <?= $post['date'] ?></small>
                                <a href="?page=post&id=<?= $post['id'] ?>" class="btn btn-<?= $cat['color'] ?> btn-sm">
                                    Xem chi tiết →
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <nav>
                <ul class="pagination justify-content-center">
                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                </ul>
            </nav>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-dark text-white fw-bold">Tin nổi bật</div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><a href="?page=post&id=1" class="text-decoration-none text-dark">AI đang thay đổi thế giới lập trình</a></li>
                    <li class="list-group-item"><a href="?page=post&id=2" class="text-decoration-none text-dark">Apple ra mắt chip M4 mới</a></li>
                    <li class="list-group-item"><a href="?page=post&id=3" class="text-decoration-none text-dark">Xu hướng Cyber Security 2026</a></li>
                    <li class="list-group-item"><a href="?page=post&id=4" class="text-decoration-none text-dark">Top framework lập trình hot nhất</a></li>
                    <li class="list-group-item"><a href="?page=post&id=5" class="text-decoration-none text-dark">ChatGPT và tương lai AI</a></li>
                </ul>
            </div>

            <div class="card bg-dark text-white shadow-sm">
                <div class="card-body">
                    <h6 class="fw-bold">📧 Đăng ký nhận tin</h6>
                    <p class="small">Nhận bài viết mới nhất về <?= $cat['name'] ?></p>
                    <input type="email" class="form-control form-control-sm mb-2" placeholder="Email của bạn">
                    <button class="btn btn-warning btn-sm w-100">Đăng ký</button>
                </div>
            </div>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>