<?php
// Chuyển hướng về list.php với id=7 (Sự kiện)
$_GET['id'] = 7;
require_once __DIR__ . '/list.php';