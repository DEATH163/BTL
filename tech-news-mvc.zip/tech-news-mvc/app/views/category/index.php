<? require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container mt-5">

<h2 class="mb-4">Danh mục Công Nghệ</h2>

<div class="row">

<?php for($i=1;$i<=6;$i++): ?>

<div class="col-md-4 mb-4">

<div class="card shadow-sm">

<img src="public/images/post.jpg" class="card-img-top">

<div class="card-body">

<h5 class="card-title">
Bài viết công nghệ <?= $i ?>
</h5>

<p>
Tin tức công nghệ mới nhất về AI, điện thoại,
lập trình và xu hướng công nghệ toàn cầu.
</p>

<a href="?page=post&id=<?= $i ?>" class="btn btn-primary btn-sm">
Xem chi tiết
</a>

</div>

</div>

</div>

<?php endfor; ?>

</div>

</div>

