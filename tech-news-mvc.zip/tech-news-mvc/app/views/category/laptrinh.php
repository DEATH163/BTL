<?php
// Chuyển hướng về list.php với id=4 (Lập trình)
$_GET['id'] = 4;
require_once __DIR__ . '/list.php';