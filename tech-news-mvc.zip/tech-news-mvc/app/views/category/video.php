<? require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container mt-4">

    <h2 class="mb-4">🎬 Video Công Nghệ</h2>

    <div class="row">

        <?php
        $videos = [
            ['id'=>1, 'title'=>'AI đang thay đổi ngành lập trình',    'yt'=>'dQw4w9WgXcQ', 'desc'=>'Khám phá cách AI đang cách mạng hóa cách chúng ta viết code.'],
            ['id'=>2, 'title'=>'Review MacBook Pro M4',                 'yt'=>'dQw4w9WgXcQ', 'desc'=>'Đánh giá chi tiết MacBook Pro trang bị chip M4 mới nhất.'],
            ['id'=>3, 'title'=>'Học Laravel từ A đến Z',                'yt'=>'dQw4w9WgXcQ', 'desc'=>'Khóa học Laravel 11 đầy đủ cho người mới bắt đầu.'],
            ['id'=>4, 'title'=>'ChatGPT vs Gemini vs Claude',           'yt'=>'dQw4w9WgXcQ', 'desc'=>'So sánh toàn diện 3 AI model hàng đầu hiện nay.'],
            ['id'=>5, 'title'=>'Cyber Security 2026 - Xu hướng mới',   'yt'=>'dQw4w9WgXcQ', 'desc'=>'Những mối đe dọa bảo mật và cách phòng chống hiệu quả.'],
            ['id'=>6, 'title'=>'Python cho Data Science',               'yt'=>'dQw4w9WgXcQ', 'desc'=>'Hướng dẫn phân tích dữ liệu với Python, Pandas và Matplotlib.'],
        ];
        ?>

        <?php foreach ($videos as $v): ?>
        <div class="col-md-6 mb-5">
            <div class="card shadow border-0">
                <div class="ratio ratio-16x9">
                    <iframe
                        src="https://www.youtube.com/embed/<?= $v['yt'] ?>"
                        title="<?= htmlspecialchars($v['title']) ?>"
                        allowfullscreen
                    ></iframe>
                </div>
                <div class="card-body">
                    <h5 class="fw-bold"><?= htmlspecialchars($v['title']) ?></h5>
                    <p class="text-muted small"><?= htmlspecialchars($v['desc']) ?></p>
                    <a href="?page=post&id=<?= $v['id'] ?>" class="btn btn-outline-primary btn-sm">
                        Đọc thêm →
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

    </div>

</div>

