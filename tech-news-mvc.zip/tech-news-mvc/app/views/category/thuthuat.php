<?php
// Chuyển hướng về list.php với id=8 (Thủ thuật)
$_GET['id'] = 8;
require_once __DIR__ . '/list.php';