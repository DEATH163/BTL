<? require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container mt-4">

    <h2 class="mb-4">📬 Liên hệ</h2>

    <div class="row">

        <div class="col-lg-7">
            <div class="card shadow border-0 p-4">
                <h4 class="mb-3">Gửi tin nhắn cho chúng tôi</h4>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Họ và tên</label>
                    <input type="text" class="form-control" placeholder="Nguyễn Văn A">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Email</label>
                    <input type="email" class="form-control" placeholder="email@example.com">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Tiêu đề</label>
                    <input type="text" class="form-control" placeholder="Tiêu đề tin nhắn">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nội dung</label>
                    <textarea class="form-control" rows="5" placeholder="Nội dung tin nhắn..."></textarea>
                </div>
                <button class="btn btn-primary">📤 Gửi tin nhắn</button>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card shadow-sm mb-3 border-0">
                <div class="card-body">
                    <h5 class="fw-bold">📍 Thông tin liên hệ</h5>
                    <ul class="list-unstyled mt-3">
                        <li class="mb-2">📧 <strong>Email:</strong> contact@technews.vn</li>
                        <li class="mb-2">📞 <strong>Điện thoại:</strong> 0901 234 567</li>
                        <li class="mb-2">🏢 <strong>Địa chỉ:</strong> 123 Đường Công Nghệ, Quận 1, TP.HCM</li>
                        <li class="mb-2">🕘 <strong>Giờ làm việc:</strong> T2 - T6, 8:00 - 17:30</li>
                    </ul>
                </div>
            </div>

            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5 class="fw-bold">🌐 Mạng xã hội</h5>
                    <div class="d-flex gap-2 mt-3 flex-wrap">
                        <a href="#" class="btn btn-primary btn-sm">Facebook</a>
                        <a href="#" class="btn btn-danger btn-sm">YouTube</a>
                        <a href="#" class="btn btn-info text-white btn-sm">Twitter</a>
                        <a href="#" class="btn btn-dark btn-sm">TikTok</a>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

