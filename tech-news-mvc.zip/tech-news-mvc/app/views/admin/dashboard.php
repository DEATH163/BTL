<?php
// $conn đã có từ AdminController

$alert = '';
$action = $_POST['action'] ?? '';

// ============================================================
// THÊM
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'create') {
    $title       = trim($_POST['title'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $content     = trim($_POST['content'] ?? '');
    // Thumbnail tự động: picsum dựa theo timestamp để luôn mới
    $thumbnail   = 'https://picsum.photos/seed/' . time() . '/800/450';

    if ($title && $category_id) {
        $stmt = $conn->prepare("INSERT INTO posts (title, content, thumbnail, category_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $title, $content, $thumbnail, $category_id);
        $stmt->execute();
        $stmt->close();
        $alert = '<div class="alert alert-success alert-dismissible fade show">✅ Thêm bài viết thành công! <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    } else {
        $alert = '<div class="alert alert-warning alert-dismissible fade show">⚠️ Vui lòng nhập đủ tiêu đề và danh mục. <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}

// ============================================================
// CẬP NHẬT
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update') {
    $id          = (int)($_POST['id'] ?? 0);
    $title       = trim($_POST['title'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $content     = trim($_POST['content'] ?? '');
    $thumbnail   = trim($_POST['thumbnail'] ?? '');

    if ($id && $title && $category_id) {
        $stmt = $conn->prepare("UPDATE posts SET title=?, content=?, thumbnail=?, category_id=? WHERE id=?");
        $stmt->bind_param("sssii", $title, $content, $thumbnail, $category_id, $id);
        $stmt->execute();
        $stmt->close();
        $alert = '<div class="alert alert-info alert-dismissible fade show">✏️ Cập nhật bài viết thành công! <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}

// ============================================================
// XÓA
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id) {
        $stmt = $conn->prepare("DELETE FROM comments WHERE post_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $alert = '<div class="alert alert-danger alert-dismissible fade show">🗑️ Đã xóa bài viết! <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}

// ============================================================
// LẤY DỮ LIỆU
// ============================================================
$catRows = $conn->query("SELECT DISTINCT id, name FROM categories ORDER BY name")->fetch_all(MYSQLI_ASSOC);

$search    = trim($_GET['search'] ?? '');
$filterCat = (int)($_GET['cat'] ?? 0);
$where     = "WHERE 1=1";
$params    = [];
$types     = '';

if ($search !== '') { $where .= " AND p.title LIKE ?"; $params[] = "%$search%"; $types .= 's'; }
if ($filterCat > 0) { $where .= " AND p.category_id = ?"; $params[] = $filterCat; $types .= 'i'; }

$sql  = "SELECT p.*, c.name AS category_name FROM posts p LEFT JOIN categories c ON p.category_id = c.id $where ORDER BY p.id DESC";
$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$posts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$totalPosts    = (int)$conn->query("SELECT COUNT(*) FROM posts")->fetch_row()[0];
$totalComments = (int)$conn->query("SELECT COUNT(*) FROM comments")->fetch_row()[0];
$totalCats     = (int)$conn->query("SELECT COUNT(DISTINCT name) FROM categories")->fetch_row()[0];

// Helper: trả về URL ảnh hợp lệ, fallback về picsum theo id bài viết
function getThumb(?string $thumbnail, int $postId): string {
    if ($thumbnail && str_starts_with($thumbnail, 'http')) {
        return $thumbnail; // URL picsum đã lưu
    }
    if ($thumbnail && file_exists($_SERVER['DOCUMENT_ROOT'] . '/tech-news-mvc/' . $thumbnail)) {
        return '/' . ltrim($thumbnail, '/'); // file local tồn tại
    }
    // Fallback: ảnh tự động theo id bài viết (seed cố định → ảnh ổn định)
    return "https://picsum.photos/seed/post{$postId}/800/450";
}
?>

<style>
.stat-card { transition: transform .2s; }
.stat-card:hover { transform: translateY(-4px); }
.thumb-sm {
    width: 60px; height: 40px;
    object-fit: cover;
    border-radius: 6px;
    border: 1px solid #dee2e6;
}
</style>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">⚙️ Admin Dashboard</h2>
        <a href="?page=home" class="btn btn-outline-secondary btn-sm">← Về trang chủ</a>
    </div>

    <?= $alert ?>

    <!-- THỐNG KÊ -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-primary shadow border-0 stat-card">
                <div class="card-body text-center py-4">
                    <h1 class="fw-bold"><?= $totalPosts ?></h1>
                    <p class="mb-0">📰 Bài viết</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-success shadow border-0 stat-card">
                <div class="card-body text-center py-4">
                    <h1 class="fw-bold"><?= $totalCats ?></h1>
                    <p class="mb-0">📂 Danh mục</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-warning shadow border-0 stat-card">
                <div class="card-body text-center py-4">
                    <h1 class="fw-bold"><?= $totalComments ?></h1>
                    <p class="mb-0">💬 Bình luận</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-white bg-danger shadow border-0 stat-card">
                <div class="card-body text-center py-4">
                    <h1 class="fw-bold">4.2K</h1>
                    <p class="mb-0">👁️ Lượt xem</p>
                </div>
            </div>
        </div>
    </div>

    <!-- TÌM KIẾM & LỌC -->
    <form method="GET" class="card shadow border-0 mb-3">
        <input type="hidden" name="page" value="admin">
        <div class="card-body py-2">
            <div class="row g-2 align-items-center">
                <div class="col-md-5">
                    <input type="text" name="search" class="form-control form-control-sm"
                           placeholder="🔍 Tìm kiếm tiêu đề..."
                           value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-3">
                    <select name="cat" class="form-select form-select-sm">
                        <option value="">-- Tất cả danh mục --</option>
                        <?php foreach ($catRows as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= $filterCat === (int)$cat['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4 d-flex gap-2 justify-content-end">
                    <button type="submit" class="btn btn-outline-primary btn-sm">🔍 Lọc</button>
                    <a href="?page=admin" class="btn btn-outline-secondary btn-sm">↺ Reset</a>
                    <button type="button" class="btn btn-success btn-sm"
                            data-bs-toggle="modal" data-bs-target="#modalCreate">+ Thêm</button>
                </div>
            </div>
        </div>
    </form>

    <!-- BẢNG BÀI VIẾT -->
    <div class="card shadow border-0">
        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
            <span>📋 Quản lý bài viết</span>
            <small class="text-muted">Hiển thị <?= count($posts) ?> / <?= $totalPosts ?> bài</small>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Ảnh</th>
                            <th>Tiêu đề</th>
                            <th>Danh mục</th>
                            <th>Ngày đăng</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($posts)): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">Không tìm thấy bài viết nào.</td></tr>
                    <?php else: ?>
                        <?php foreach ($posts as $p):
                            $thumbUrl = getThumb($p['thumbnail'], $p['id']);
                            // Gán thumbnail đã resolve để JS dùng
                            $p['thumb_url'] = $thumbUrl;
                        ?>
                        <tr>
                            <td><?= $p['id'] ?></td>
                            <td>
                                <img src="<?= htmlspecialchars($thumbUrl) ?>"
                                     class="thumb-sm" alt="ảnh bài viết"
                                     loading="lazy">
                            </td>
                            <td>
                                <a href="?page=post&id=<?= $p['id'] ?>" class="text-decoration-none fw-semibold">
                                    <?= htmlspecialchars($p['title']) ?>
                                </a>
                            </td>
                            <td><span class="badge bg-secondary"><?= htmlspecialchars($p['category_name'] ?? '—') ?></span></td>
                            <td><?= date('d/m/Y', strtotime($p['created_at'])) ?></td>
                            <td>
                                <button class="btn btn-outline-primary btn-sm"
                                    onclick='openView(<?= json_encode($p, JSON_HEX_QUOT | JSON_HEX_APOS) ?>)'
                                    title="Xem">👁</button>
                                <button class="btn btn-outline-warning btn-sm"
                                    onclick='openEdit(<?= json_encode($p, JSON_HEX_QUOT | JSON_HEX_APOS) ?>)'
                                    title="Sửa">✏️</button>
                                <button class="btn btn-outline-danger btn-sm"
                                    onclick="openDelete(<?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['title'])) ?>')"
                                    title="Xóa">🗑</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: THÊM -->
<div class="modal fade" id="modalCreate" tabindex="-1">
    <div class="modal-dialog modal-lg"><div class="modal-content">
        <form method="POST">
            <input type="hidden" name="action" value="create">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">➕ Thêm bài viết mới</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <!-- Preview ảnh tự động -->
                <div class="mb-3 text-center">
                    <img id="createThumbPreview"
                         src="https://picsum.photos/seed/new/800/450"
                         class="img-fluid rounded shadow-sm" style="max-height:160px;object-fit:cover;width:100%"
                         alt="ảnh tự động">
                    <small class="text-muted d-block mt-1">🖼️ Ảnh sẽ được tự động gán khi lưu</small>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Tiêu đề <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" required placeholder="Nhập tiêu đề...">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Danh mục <span class="text-danger">*</span></label>
                    <select name="category_id" class="form-select" required>
                        <option value="">-- Chọn danh mục --</option>
                        <?php foreach ($catRows as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nội dung</label>
                    <textarea name="content" class="form-control" rows="5" placeholder="Nhập nội dung bài viết..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="submit" class="btn btn-success">💾 Lưu bài viết</button>
            </div>
        </form>
    </div></div>
</div>

<!-- MODAL: XEM -->
<div class="modal fade" id="modalView" tabindex="-1">
    <div class="modal-dialog modal-lg"><div class="modal-content">
        <div class="modal-header bg-primary text-white">
            <h5 class="modal-title">👁 Chi tiết bài viết</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
            <img id="viewThumb" src="" alt="thumbnail"
                 class="img-fluid rounded shadow mb-3 w-100"
                 style="max-height:220px;object-fit:cover">
            <h4 id="viewTitle" class="fw-bold mb-2"></h4>
            <div class="mb-2 d-flex gap-3 align-items-center flex-wrap">
                <span class="badge bg-secondary" id="viewCat"></span>
                <small class="text-muted" id="viewDate"></small>
            </div>
            <hr>
            <p id="viewContent" class="text-secondary" style="white-space:pre-wrap"></p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
        </div>
    </div></div>
</div>

<!-- MODAL: SỬA -->
<div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog modal-lg"><div class="modal-content">
        <form method="POST">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" id="editId">
            <input type="hidden" name="thumbnail" id="editThumbnailHidden">
            <div class="modal-header bg-warning">
                <h5 class="modal-title">✏️ Chỉnh sửa bài viết</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <!-- Preview ảnh hiện tại -->
                <div class="mb-3 text-center">
                    <img id="editThumbPreview" src="" alt="thumbnail"
                         class="img-fluid rounded shadow-sm" style="max-height:160px;object-fit:cover;width:100%">
                    <small class="text-muted d-block mt-1">🖼️ Ảnh tự động — giữ nguyên khi cập nhật</small>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Tiêu đề <span class="text-danger">*</span></label>
                    <input type="text" name="title" id="editTitle" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Danh mục <span class="text-danger">*</span></label>
                    <select name="category_id" id="editCategory" class="form-select" required>
                        <?php foreach ($catRows as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Nội dung</label>
                    <textarea name="content" id="editContent" class="form-control" rows="5"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="submit" class="btn btn-warning">💾 Cập nhật</button>
            </div>
        </form>
    </div></div>
</div>

<!-- MODAL: XÓA -->
<div class="modal fade" id="modalDelete" tabindex="-1">
    <div class="modal-dialog"><div class="modal-content">
        <form method="POST">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" id="deleteId">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">🗑 Xác nhận xóa</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Bạn có chắc muốn xóa bài viết:</p>
                <p class="fw-bold fst-italic" id="deleteTitle"></p>
                <div class="alert alert-warning py-2 small mb-0">
                    ⚠️ Tất cả bình luận liên quan cũng sẽ bị xóa và không thể hoàn tác!
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="submit" class="btn btn-danger">🗑 Xóa</button>
            </div>
        </form>
    </div></div>
</div>

<script>
function getAutoThumb(id) {
    return 'https://picsum.photos/seed/post' + id + '/800/450';
}

function openView(p) {
    document.getElementById('viewThumb').src           = p.thumb_url || getAutoThumb(p.id);
    document.getElementById('viewTitle').textContent   = p.title;
    document.getElementById('viewCat').textContent     = p.category_name || '—';
    document.getElementById('viewDate').textContent    = '📅 ' + p.created_at;
    document.getElementById('viewContent').textContent = p.content || 'Không có nội dung.';
    new bootstrap.Modal(document.getElementById('modalView')).show();
}

function openEdit(p) {
    const thumb = p.thumb_url || getAutoThumb(p.id);
    document.getElementById('editId').value              = p.id;
    document.getElementById('editTitle').value           = p.title;
    document.getElementById('editContent').value         = p.content || '';
    document.getElementById('editThumbnailHidden').value = thumb; // giữ lại ảnh cũ
    document.getElementById('editThumbPreview').src      = thumb;
    const sel = document.getElementById('editCategory');
    for (let opt of sel.options) opt.selected = (opt.value == p.category_id);
    new bootstrap.Modal(document.getElementById('modalEdit')).show();
}

function openDelete(id, title) {
    document.getElementById('deleteId').value          = id;
    document.getElementById('deleteTitle').textContent = '"' + title + '"';
    new bootstrap.Modal(document.getElementById('modalDelete')).show();
}
</script>