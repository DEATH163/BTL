<!DOCTYPE html>
<html lang="vi">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Tech News</title>

<link rel="stylesheet" href="public/css/style.css">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
rel="stylesheet"
>

</head>

<body>

<!-- NAVBAR -->

<nav class="navbar navbar-dark navbar-expand-lg bg-dark shadow">

<div class="container">

<a class="navbar-brand fw-bold" href="?page=home">
TechNews
</a>

<button
class="navbar-toggler"
type="button"
data-bs-toggle="collapse"
data-bs-target="#menu"
>
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<!-- MENU -->

<ul class="navbar-nav me-auto">

<li class="nav-item">
<a class="nav-link" href="?page=home">Trang chủ</a>
</li>

<li class="nav-item">
<a class="nav-link" href="?page=category&id=1">Công nghệ</a>
</li>

<li class="nav-item">
<a class="nav-link" href="?page=category&id=4">Lập trình</a>
</li>

<li class="nav-item">
<a class="nav-link" href="?page=category&id=7">Sự kiện</a>
</li>

<li class="nav-item">
<a class="nav-link" href="?page=category&id=8">Thủ thuật</a>
</li>

<li class="nav-item">
<a class="nav-link" href="?page=video">Video</a>
</li>

<li class="nav-item">
<a class="nav-link" href="?page=contact">Liên hệ</a>
</li>

<li class="nav-item">
<a class="nav-link text-warning" href="?page=admin">Admin</a>
</li>

</ul>

<!-- SEARCH -->

<!-- Thay action="index.php" thành không có action (để trống) -->
<form class="d-flex" method="GET">

    <input type="hidden" name="page" value="search">

    <input
        class="form-control me-2"
        type="search"
        name="keyword"
        placeholder="Tìm kiếm bài viết..."
        value="<?= htmlspecialchars($_GET['keyword'] ?? '') ?>"
    >

    <button type="submit" class="btn btn-outline-light">
        Search
    </button>

</form>

</div>

</div>

</nav>


<!-- BANNER -->

<div class="bg-warning py-2">

<div class="container">

<strong>
TRANG TIN TỨC CÔNG NGHỆ MỚI NHẤT
</strong>

</div>

</div>


<!-- CONTENT -->

<div class="container mt-4">