<?php

require_once "app/config/database.php";
require_once "app/core/Router.php";

$router = new Router();
$router->handleRequest();
